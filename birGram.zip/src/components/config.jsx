const Config = {
  apiUrl: "https://gold.pronetwork.cloud/api/v1",
  baseUrl: "https://gold.pronetwork.cloud",
  // apiUrl: "http://192.168.1.21/api/v1",
  // baseUrl: "http://192.168.1.21",
};
export default Config;
