(()=>{var e={};e.id=4975,e.ids=[4975],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},12412:e=>{"use strict";e.exports=require("assert")},94735:e=>{"use strict";e.exports=require("events")},29021:e=>{"use strict";e.exports=require("fs")},81630:e=>{"use strict";e.exports=require("http")},55591:e=>{"use strict";e.exports=require("https")},21820:e=>{"use strict";e.exports=require("os")},33873:e=>{"use strict";e.exports=require("path")},27910:e=>{"use strict";e.exports=require("stream")},83997:e=>{"use strict";e.exports=require("tty")},79551:e=>{"use strict";e.exports=require("url")},28354:e=>{"use strict";e.exports=require("util")},74075:e=>{"use strict";e.exports=require("zlib")},63125:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>o.a,__next_app__:()=>u,pages:()=>d,routeModule:()=>p,tree:()=>c});var s=r(70260),i=r(28203),a=r(25155),o=r.n(a),n=r(67292),l={};for(let e in n)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>n[e]);r.d(t,l);let c=["",{children:["(public)",{children:["contact-us",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,90258)),"C:\\project\\birgram\\birGram\\src\\app\\(public)\\contact-us\\page.jsx"]}]},{}]},{forbidden:[()=>Promise.resolve().then(r.t.bind(r,69116,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,41485,23)),"next/dist/client/components/unauthorized-error"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,62804)),"C:\\project\\birgram\\birGram\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(r.bind(r,76868)),"C:\\project\\birgram\\birGram\\src\\app\\not-found.jsx"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,69116,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,41485,23)),"next/dist/client/components/unauthorized-error"]}],d=["C:\\project\\birgram\\birGram\\src\\app\\(public)\\contact-us\\page.jsx"],u={require:r,loadChunk:()=>Promise.resolve()},p=new s.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/(public)/contact-us/page",pathname:"/contact-us",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},78421:(e,t,r)=>{Promise.resolve().then(r.bind(r,90258))},20277:(e,t,r)=>{Promise.resolve().then(r.bind(r,25497))},25497:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>b});var s=r(45512);r(70918),r(62392),r(5637);var i=r(4681),a=r(88029),o=r(73992),n=r(7194),l=r(58009),c=r.n(l);function d(){return(d=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var s in r)({}).hasOwnProperty.call(r,s)&&(e[s]=r[s])}return e}).apply(null,arguments)}var u=function(e,t){if("function"==typeof e){e(t);return}e.current=t},p=function(e,t){var r=c().useRef();return c().useCallback(function(s){e.current=s,r.current&&u(r.current,null),r.current=t,t&&u(t,s)},[t])},m=function(){},f=["cacheMeasurements","maxRows","minRows","onChange","onHeightChange"],h=l.forwardRef(function(e,t){e.cacheMeasurements,e.maxRows,e.minRows;var r=e.onChange;e.onHeightChange;var s=function(e,t){if(null==e)return{};var r={};for(var s in e)if(({}).hasOwnProperty.call(e,s)){if(t.includes(s))continue;r[s]=e[s]}return r}(e,f);s.value;var i=p(l.useRef(null),t);return l.useRef(0),l.useRef(),l.createElement("textarea",d({},s,{onChange:void 0===r?m:r,ref:i}))}),g=r(51772);(0,o.Rf)(({style:e,minRows:t=3,maxRows:r=8,cacheMeasurements:o=!1,disableAutosize:c=!1,onHeightChange:d,...u},p)=>{let{Component:m,label:f,description:b,startContent:x,endContent:y,hasHelper:v,shouldLabelBeOutside:w,shouldLabelBeInside:j,isInvalid:E,errorMessage:C,getBaseProps:P,getLabelProps:k,getInputProps:q,getInnerWrapperProps:$,getInputWrapperProps:_,getHelperWrapperProps:O,getDescriptionProps:z,getErrorMessageProps:A,isClearable:R,getClearButtonProps:D}=(0,i.G)({...u,ref:p,isMultiline:!0}),[M,N]=(0,l.useState)(t>1),[G,H]=(0,l.useState)(!1),I=f?(0,s.jsx)("label",{...k(),children:f}):null,T=q(),S=c?(0,s.jsx)("textarea",{...T,style:(0,n.v)(T.style,null!=e?e:{})}):(0,s.jsx)(h,{...T,cacheMeasurements:o,"data-hide-scroll":(0,a.sE)(!G),maxRows:r,minRows:t,style:(0,n.v)(T.style,null!=e?e:{}),onHeightChange:(e,s)=>{1===t&&N(e>=2*s.rowHeight),r>t&&H(e>=r*s.rowHeight),null==d||d(e,s)}}),F=(0,l.useMemo)(()=>R?(0,s.jsx)("button",{...D(),children:(0,s.jsx)(g.o,{})}):null,[R,D]),L=(0,l.useMemo)(()=>x||y?(0,s.jsxs)("div",{...$(),children:[x,S,y]}):(0,s.jsx)("div",{...$(),children:S}),[x,T,y,$]),U=E&&C,B=U||b;return(0,s.jsxs)(m,{...P(),children:[w?I:null,(0,s.jsxs)("div",{..._(),"data-has-multiple-rows":(0,a.sE)(M),children:[j?I:null,L,F]}),v&&B?(0,s.jsx)("div",{...O(),children:U?(0,s.jsx)("div",{...A(),children:C}):(0,s.jsx)("div",{...z(),children:b})}):null]})}).displayName="NextUI.Textarea",r(58737),r(45103),r(6868),r(85668),r(70305),r(28531),r(22403);let b=function(){return null}},90258:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>s});let s=(0,r(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\project\\\\birgram\\\\birGram\\\\src\\\\app\\\\(public)\\\\contact-us\\\\page.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\project\\birgram\\birGram\\src\\app\\(public)\\contact-us\\page.jsx","default")},22403:(e,t,r)=>{"use strict";r.d(t,{l$:()=>ec,Ay:()=>ed,oR:()=>R});var s,i=r(58009);let a={data:""},o=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||a,n=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,c=/\n+/g,d=(e,t)=>{let r="",s="",i="";for(let a in e){let o=e[a];"@"==a[0]?"i"==a[1]?r=a+" "+o+";":s+="f"==a[1]?d(o,a):a+"{"+d(o,"k"==a[1]?"":t)+"}":"object"==typeof o?s+=d(o,t?t.replace(/([^,])+/g,e=>a.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):a):null!=o&&(a=/^--/.test(a)?a:a.replace(/[A-Z]/g,"-$&").toLowerCase(),i+=d.p?d.p(a,o):a+":"+o+";")}return r+(t&&i?t+"{"+i+"}":i)+s},u={},p=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+p(e[r]);return t}return e},m=(e,t,r,s,i)=>{let a=p(e),o=u[a]||(u[a]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(a));if(!u[o]){let t=a!==e?e:(e=>{let t,r,s=[{}];for(;t=n.exec(e.replace(l,""));)t[4]?s.shift():t[3]?(r=t[3].replace(c," ").trim(),s.unshift(s[0][r]=s[0][r]||{})):s[0][t[1]]=t[2].replace(c," ").trim();return s[0]})(e);u[o]=d(i?{["@keyframes "+o]:t}:t,r?"":"."+o)}let m=r&&u.g?u.g:null;return r&&(u.g=u[o]),((e,t,r,s)=>{s?t.data=t.data.replace(s,e):-1===t.data.indexOf(e)&&(t.data=r?e+t.data:t.data+e)})(u[o],t,s,m),o},f=(e,t,r)=>e.reduce((e,s,i)=>{let a=t[i];if(a&&a.call){let e=a(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;a=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+s+(null==a?"":a)},"");function h(e){let t=this||{},r=e.call?e(t.p):e;return m(r.unshift?r.raw?f(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,o(t.target),t.g,t.o,t.k)}h.bind({g:1});let g,b,x,y=h.bind({k:1});function v(e,t){let r=this||{};return function(){let s=arguments;function i(a,o){let n=Object.assign({},a),l=n.className||i.className;r.p=Object.assign({theme:b&&b()},n),r.o=/ *go\d+/.test(l),n.className=h.apply(r,s)+(l?" "+l:""),t&&(n.ref=o);let c=e;return e[0]&&(c=n.as||e,delete n.as),x&&c[0]&&x(n),g(c,n)}return t?t(i):i}}var w=e=>"function"==typeof e,j=(e,t)=>w(e)?e(t):e,E=(()=>{let e=0;return()=>(++e).toString()})(),C=(()=>{let e;return()=>e})(),P=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return P(e,{type:e.toasts.find(e=>e.id===r.id)?1:0,toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},k=[],q={toasts:[],pausedAt:void 0},$=e=>{q=P(q,e),k.forEach(e=>{e(q)})},_={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},O=(e={})=>{let[t,r]=(0,i.useState)(q);(0,i.useEffect)(()=>(k.push(r),()=>{let e=k.indexOf(r);e>-1&&k.splice(e,1)}),[t]);let s=t.toasts.map(t=>{var r,s,i;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(s=e[t.type])?void 0:s.duration)||(null==e?void 0:e.duration)||_[t.type],style:{...e.style,...null==(i=e[t.type])?void 0:i.style,...t.style}}});return{...t,toasts:s}},z=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||E()}),A=e=>(t,r)=>{let s=z(t,e,r);return $({type:2,toast:s}),s.id},R=(e,t)=>A("blank")(e,t);R.error=A("error"),R.success=A("success"),R.loading=A("loading"),R.custom=A("custom"),R.dismiss=e=>{$({type:3,toastId:e})},R.remove=e=>$({type:4,toastId:e}),R.promise=(e,t,r)=>{let s=R.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let i=t.success?j(t.success,e):void 0;return i?R.success(i,{id:s,...r,...null==r?void 0:r.success}):R.dismiss(s),e}).catch(e=>{let i=t.error?j(t.error,e):void 0;i?R.error(i,{id:s,...r,...null==r?void 0:r.error}):R.dismiss(s)}),e};var D=(e,t)=>{$({type:1,toast:{id:e,height:t}})},M=()=>{$({type:5,time:Date.now()})},N=new Map,G=1e3,H=(e,t=G)=>{if(N.has(e))return;let r=setTimeout(()=>{N.delete(e),$({type:4,toastId:e})},t);N.set(e,r)},I=e=>{let{toasts:t,pausedAt:r}=O(e);(0,i.useEffect)(()=>{if(r)return;let e=Date.now(),s=t.map(t=>{if(t.duration===1/0)return;let r=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(r<0){t.visible&&R.dismiss(t.id);return}return setTimeout(()=>R.dismiss(t.id),r)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[t,r]);let s=(0,i.useCallback)(()=>{r&&$({type:6,time:Date.now()})},[r]),a=(0,i.useCallback)((e,r)=>{let{reverseOrder:s=!1,gutter:i=8,defaultPosition:a}=r||{},o=t.filter(t=>(t.position||a)===(e.position||a)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...s?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+i,0)},[t]);return(0,i.useEffect)(()=>{t.forEach(e=>{if(e.dismissed)H(e.id,e.removeDelay);else{let t=N.get(e.id);t&&(clearTimeout(t),N.delete(e.id))}})},[t]),{toasts:t,handlers:{updateHeight:D,startPause:M,endPause:s,calculateOffset:a}}},T=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,S=y`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,F=y`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,L=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${T} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${S} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,U=y`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,B=v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${U} 1s linear infinite;
`,K=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,X=y`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Y=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${K} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${X} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,Z=v("div")`
  position: absolute;
`,J=v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,Q=y`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,V=v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${Q} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,W=({toast:e})=>{let{icon:t,type:r,iconTheme:s}=e;return void 0!==t?"string"==typeof t?i.createElement(V,null,t):t:"blank"===r?null:i.createElement(J,null,i.createElement(B,{...s}),"loading"!==r&&i.createElement(Z,null,"error"===r?i.createElement(L,{...s}):i.createElement(Y,{...s})))},ee=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,et=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,er=v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,es=v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ei=(e,t)=>{let r=e.includes("top")?1:-1,[s,i]=C()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ee(r),et(r)];return{animation:t?`${y(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${y(i)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ea=i.memo(({toast:e,position:t,style:r,children:s})=>{let a=e.height?ei(e.position||t||"top-center",e.visible):{opacity:0},o=i.createElement(W,{toast:e}),n=i.createElement(es,{...e.ariaProps},j(e.message,e));return i.createElement(er,{className:e.className,style:{...a,...r,...e.style}},"function"==typeof s?s({icon:o,message:n}):i.createElement(i.Fragment,null,o,n))});s=i.createElement,d.p=void 0,g=s,b=void 0,x=void 0;var eo=({id:e,className:t,style:r,onHeightUpdate:s,children:a})=>{let o=i.useCallback(t=>{if(t){let r=()=>{s(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,s]);return i.createElement("div",{ref:o,className:t,style:r},a)},en=(e,t)=>{let r=e.includes("top"),s=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:C()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...s}},el=h`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ec=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:s,children:a,containerStyle:o,containerClassName:n})=>{let{toasts:l,handlers:c}=I(r);return i.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...o},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},l.map(r=>{let o=r.position||t,n=en(o,c.calculateOffset(r,{reverseOrder:e,gutter:s,defaultPosition:t}));return i.createElement(eo,{id:r.id,key:r.id,onHeightUpdate:c.updateHeight,className:r.visible?el:"",style:n},"custom"===r.type?j(r.message,r):a?a(r):i.createElement(ea,{toast:r,position:o}))}))},ed=R}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[5344,5668,8531,5103,6868,8940,3984,7492,4256,5637,6365,7296,6144],()=>r(63125));module.exports=s})();